# Native controller coexistence audit

The English AnyPad source was freshly cloned at 9475e9f. Its hci_usb.c is identical to our beta6.0 transport. Beta6.1 differs only in queued reads (2 event/2 ACL versus 40/20). Both tests failed DualSense reconnect; beta6.1 also failed Move connection tests. No sufficient transport fix has been demonstrated.

Unknown connection requests and link-key events are ignored unless the address belongs to a host-managed link. The broad event masks, SSP setup, and LE scan setup were inherited. Beta6.1 skips those writes for Move/Nav; this was verified by a simulator command-policy test, but hardware reconnection still failed.

PoorDS4 reads Sony-published controller input and adapts application APIs. It is a source of native-path techniques, not proof that raw USB reads can coexist. Its 13.60 Move/Nav compatibility is not established.

Next isolation tests are finite 45-second payloads and send no HCI commands:

- MoveStudio-NativeBT-OpenOnly.elf: open/allocate transport endpoints, queue no reads, then close.
- MoveStudio-NativeBT-ReadOnly.elf: open/allocate and queue reads; consume/log events without accepting connections, pairing, or other HCI commands; then close.

Run only one, with the main bridge stopped. Test native DualSense reconnection during the window; restore normal native operation through rest mode if required. An open-only failure implicates endpoint ownership; failure only while reading implicates event delivery. Neither is a completed fix.

Virtual output remains guarded off. Additional logs now bracket credential setup and each service-library load; unit tests pass. Do not enable the virtual mode merely because logging was added.

Wall-light rejection still needs a camera calibration/exclusion mechanism. Do not suppress stationary detections automatically: a user holding a Move still would be suppressed too.
